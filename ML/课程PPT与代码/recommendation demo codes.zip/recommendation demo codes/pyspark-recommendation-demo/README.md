### pyspark完成的协同过滤推荐。
itemBasedRecommender.py和userBasedRecommender.py非常简单和直接的基于物品和用户的协同过滤，Movie_Recommendation_using_pyspark.py为隐语义模型对应的电影推荐，使用的spark MLlib中的ALS。代码仅供参考，欢迎任何形式的吐槽和修改<br>
有问题可以联系[@寒小阳](http://blog.csdn.net/han_xiaoyang)<br>
邮箱：hanxiaoyang.ml@gmail.com
