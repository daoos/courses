from scrapy.cmdline import execute
execute(['scrapy','runspider', '/Users/hezhen/Projects/courses/spider/src/charpter_07/scrapy/quotes_spider.py', '-o quotes.json'])