package feature;

public class CityDiscrete {
	public static void main(String[] args)throws Exception {
		
	}
	
	public static void fun(String in,String out)throws Exception{
		
	}
}
