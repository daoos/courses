Refer to https://github.com/Microsoft/LightGBM/wiki/Installation-Guide.
