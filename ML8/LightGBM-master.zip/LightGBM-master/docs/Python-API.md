# Python API Reference

Move to [Read The Docs](http://lightgbm.readthedocs.io/en/latest/python/lightgbm.html#lightgbm-package).